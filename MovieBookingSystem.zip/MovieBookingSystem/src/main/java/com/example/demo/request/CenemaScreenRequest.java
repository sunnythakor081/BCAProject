package com.example.demo.request;

public class CenemaScreenRequest {
	
	
	private Integer id;
	private String cenemaScreenName;
	private Integer cenemaId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCenemaScreenName() {
		return cenemaScreenName;
	}
	public void setCenemaScreenName(String cenemaScreenName) {
		this.cenemaScreenName = cenemaScreenName;
	}
	public Integer getCenemaId() {
		return cenemaId;
	}
	public void setCenemaId(Integer cenemaId) {
		this.cenemaId = cenemaId;
	}
	public CenemaScreenRequest(Integer id, String cenemaScreenName, Integer cenemaId) {
		super();
		this.id = id;
		this.cenemaScreenName = cenemaScreenName;
		this.cenemaId = cenemaId;
	}
	
	
	
	
}
