package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.request.MovieCenemaRequest;
import com.example.demo.service.MovieCenemaService;

@RestController
@RequestMapping("moviecenema")
public class MovieCenemaController {

	@Autowired
	private MovieCenemaService movieCenemaService;

	@PostMapping("add_movie_in_cenema")
	public ResponseEntity<Object> addSreen(@RequestBody MovieCenemaRequest request) {
		return movieCenemaService.addMovieCenema(request);
	}

	@PutMapping("get_movies_based_on_cenema")
	public ResponseEntity<Object> getMoviesBasedOnCenema(@RequestBody MovieCenemaRequest request) {

		return movieCenemaService.getMovieBasedOnCenema(request);
	}

	@PutMapping("update_movie_state")
	public ResponseEntity<Object> updateMovieState(@RequestBody MovieCenemaRequest request) {

		return movieCenemaService.updateMovieState(request);
	}

}
