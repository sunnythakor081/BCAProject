package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity(name = "ticket")
public class TicketEntity {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@ManyToOne
	private MovieEntity movie;
	
	@ManyToOne
	private CenemaEntity cenema;
	
	@Column(name = "ticket_price")
	private Double ticketPrice;
	
	@Column(name = "show_time_period")
	private String showTimePeriod;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public MovieEntity getMovie() {
		return movie;
	}

	public void setMovie(MovieEntity movie) {
		this.movie = movie;
	}

	public CenemaEntity getCenema() {
		return cenema;
	}

	public void setCenema(CenemaEntity cenema) {
		this.cenema = cenema;
	}

	public Double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(Double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public String getShowTimePeriod() {
		return showTimePeriod;
	}

	public void setShowTimePeriod(String showTimePeriod) {
		this.showTimePeriod = showTimePeriod;
	}

	@Override
	public String toString() {
		return "TicketEntity [id=" + id + ", movie=" + movie + ", cenema=" + cenema + ", ticketPrice=" + ticketPrice
				+ ", showTimePeriod=" + showTimePeriod + "]";
	}

	public TicketEntity(Integer id, MovieEntity movie, CenemaEntity cenema, Double ticketPrice, String showTimePeriod) {
		super();
		this.id = id;
		this.movie = movie;
		this.cenema = cenema;
		this.ticketPrice = ticketPrice;
		this.showTimePeriod = showTimePeriod;
	}

	public TicketEntity() {
		// TODO Auto-generated constructor stub
	}

}
