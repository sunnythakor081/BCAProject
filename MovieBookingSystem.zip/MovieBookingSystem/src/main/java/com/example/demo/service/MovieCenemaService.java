package com.example.demo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entity.CenemaEntity;
import com.example.demo.entity.CenemaScreenEntity;
import com.example.demo.entity.MovieCenemaScreenMappingEntity;
import com.example.demo.entity.MovieEntity;
import com.example.demo.repository.CenemaRepository;
import com.example.demo.repository.CenemaScreenRepository;
import com.example.demo.repository.MovieCenemaScreenMappingRepository;
import com.example.demo.repository.MovieRepository;
import com.example.demo.request.MovieCenemaRequest;
import com.example.demo.util.ResponseData;

@Service
public class MovieCenemaService {

	@Autowired
	private CenemaRepository cenemaRepo;

	@Autowired
	private CenemaScreenRepository cenemaScreenRepo;

	@Autowired
	private MovieRepository movieRepo;

	@Autowired
	private MovieCenemaScreenMappingRepository movieCenemaScreenMappingRepo;

	public ResponseEntity<Object> addMovieCenema(MovieCenemaRequest request) {
		ResponseData responseData = new ResponseData();

		try {

			if (request == null) {
				return responseData.bedRequest("Please Provide Cenema Sit information");
			}
			if (request.getTiming() == null) {
				return responseData.bedRequest("Please provide movie timing");
			}
			if (request.getCenemaId() == null || request.getCenemaId() <= 0) {
				return responseData.bedRequest("Please provide cenema information");
			}
			if (request.getMovieId() == null || request.getMovieId() <= 0) {
				return responseData.bedRequest("Please provide movie information");
			}
			if (request.getCenemaScreenId() == null || request.getCenemaScreenId() <= 0) {
				return responseData.bedRequest("Please provide cenema screen information");
			}

			Optional<CenemaEntity> cenemaEntityOptional = cenemaRepo.findById(request.getCenemaId());

			if (!cenemaEntityOptional.isPresent()) {
				return responseData.bedRequest("cenema information not match");
			}

			Optional<CenemaScreenEntity> cenemaScreenEntityOptional = cenemaScreenRepo
					.findById(request.getCenemaScreenId());

			if (!cenemaScreenEntityOptional.isPresent()) {
				return responseData.bedRequest("cenema screen information not match");
			}

			if (!cenemaScreenEntityOptional.get().getCenema().equals(cenemaEntityOptional.get())) {
				return responseData.bedRequest("cenema and Cenema Screen information not match");
			}

			Optional<MovieEntity> movieOptional = movieRepo.findById(request.getMovieId());

			if (!movieOptional.isPresent()) {
				return responseData.bedRequest("Movie information not match");
			}

			MovieCenemaScreenMappingEntity movieCenemascreenMappping = new MovieCenemaScreenMappingEntity();

			movieCenemascreenMappping.setCenema(cenemaEntityOptional.get());
			movieCenemascreenMappping.setCenemaScreen(cenemaScreenEntityOptional.get());
			movieCenemascreenMappping.setMovie(movieOptional.get());
			movieCenemascreenMappping
					.setIsCurrentMovie(request.getIsCurrentMovie() ? request.getIsCurrentMovie() : false);
			movieCenemascreenMappping.setIsPastMovie(request.getIsPastMovie() ? request.getIsPastMovie() : false);
			movieCenemascreenMappping
					.setIsUpcommingMovie(request.getIsUpcommingMovie() ? request.getIsUpcommingMovie() : false);
			movieCenemascreenMappping.setTiming(request.getTiming());

			movieCenemaScreenMappingRepo.saveAndFlush(movieCenemascreenMappping);

			return responseData.ok("Movie added with Cenema Successfully", movieCenemascreenMappping);

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}

	}

	public ResponseEntity<Object> getMovieBasedOnCenema(MovieCenemaRequest request) {
		ResponseData responseData = new ResponseData();

		try {

			if (request == null) {
				return responseData.bedRequest("Please Provide Cenema information");
			}
			if (request.getCenemaId() == null || request.getCenemaId() <= 0) {
				return responseData.bedRequest("Please provide cenema information");
			}

			if ((request.getIsCurrentMovie() == null || request.getIsCurrentMovie() == false)
					&& (request.getIsPastMovie() == null || request.getIsPastMovie() == false)
					&& (request.getIsUpcommingMovie() == null || request.getIsUpcommingMovie() == false)) {

				return responseData.bedRequest("Please define current movie or upcomming movie or past movie");
			}

			if ((request.getIsCurrentMovie() != null && request.getIsCurrentMovie() == true)
					&& ((request.getIsPastMovie() != null && request.getIsPastMovie() == true)
							|| (request.getIsUpcommingMovie() != null && request.getIsUpcommingMovie() == true))) {

				return responseData.bedRequest("Please define current movie or upcomming movie or past movie");
			}

			if ((request.getIsPastMovie() != null && request.getIsPastMovie() == true)
					&& ((request.getIsCurrentMovie() != null && request.getIsCurrentMovie() == true)
							|| (request.getIsUpcommingMovie() != null && request.getIsUpcommingMovie() == true))) {

				return responseData.bedRequest("Please define current movie or upcomming movie or past movie");
			}

			if ((request.getIsUpcommingMovie() != null && request.getIsUpcommingMovie() == true)
					&& ((request.getIsCurrentMovie() != null && request.getIsCurrentMovie() == true)
							|| (request.getIsPastMovie() != null && request.getIsPastMovie() == true))) {

				return responseData.bedRequest("Please define current movie or upcomming movie or past movie");
			}

			Optional<CenemaEntity> cenemaEntityOptional = cenemaRepo.findById(request.getCenemaId());

			if (!cenemaEntityOptional.isPresent()) {
				return responseData.bedRequest("cenema information not match");
			}

			List<MovieCenemaScreenMappingEntity> movieCenemascreenMapppingList = null;
			if (request.getIsCurrentMovie()) {

				movieCenemascreenMapppingList = movieCenemaScreenMappingRepo
						.findByCenemaAndIsCurrentMovieTrue(cenemaEntityOptional.get());
			} else if (request.getIsPastMovie()) {

				movieCenemascreenMapppingList = movieCenemaScreenMappingRepo
						.findByCenemaAndIsPastMovieTrue(cenemaEntityOptional.get());

			} else if (request.getIsUpcommingMovie()) {

				movieCenemascreenMapppingList = movieCenemaScreenMappingRepo
						.findByCenemaAndIsUpcommingMovieTrue(cenemaEntityOptional.get());
			}

			if (movieCenemascreenMapppingList == null || movieCenemascreenMapppingList.size() <= 0) {
				return responseData.bedRequest("No Movie information found");
			}

			List<MovieEntity> movieList = movieCenemascreenMapppingList.stream().map(s -> s.getMovie())
					.collect(Collectors.toList());

			return responseData.ok("Movie found Successfully", movieList);

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}

	}

	public ResponseEntity<Object> updateMovieState(MovieCenemaRequest request) {
		ResponseData responseData = new ResponseData();

		try {

			if (request == null) {
				return responseData.bedRequest("Please Provide Cenema Sit information");
			}
			if (request.getCenemaId() == null || request.getCenemaId() <= 0) {
				return responseData.bedRequest("Please provide cenema information");
			}
			if (request.getMovieId() == null || request.getMovieId() <= 0) {
				return responseData.bedRequest("Please provide movie information");
			}
			if ((request.getIsCurrentMovie() == null || request.getIsCurrentMovie() == false)
					&& (request.getIsPastMovie() == null || request.getIsPastMovie() == false)
					&& (request.getIsUpcommingMovie() == null || request.getIsUpcommingMovie() == false)) {

				return responseData.bedRequest("Please define current movie or upcomming movie or past movie");
			}

			if ((request.getIsCurrentMovie() != null && request.getIsCurrentMovie() == true)
					&& ((request.getIsPastMovie() != null && request.getIsPastMovie() == true)
							|| (request.getIsUpcommingMovie() != null && request.getIsUpcommingMovie() == true))) {

				return responseData.bedRequest("Please define current movie or upcomming movie or past movie");
			}

			if ((request.getIsPastMovie() != null && request.getIsPastMovie() == true)
					&& ((request.getIsCurrentMovie() != null && request.getIsCurrentMovie() == true)
							|| (request.getIsUpcommingMovie() != null && request.getIsUpcommingMovie() == true))) {

				return responseData.bedRequest("Please define current movie or upcomming movie or past movie");
			}

			if ((request.getIsUpcommingMovie() != null && request.getIsUpcommingMovie() == true)
					&& ((request.getIsCurrentMovie() != null && request.getIsCurrentMovie() == true)
							|| (request.getIsPastMovie() != null && request.getIsPastMovie() == true))) {

				return responseData.bedRequest("Please define current movie or upcomming movie or past movie");
			}

			Optional<CenemaEntity> cenemaEntityOptional = cenemaRepo.findById(request.getCenemaId());

			if (!cenemaEntityOptional.isPresent()) {
				return responseData.bedRequest("cenema information not match");
			}

			Optional<MovieEntity> movieOptional = movieRepo.findById(request.getMovieId());

			if (!movieOptional.isPresent()) {
				return responseData.bedRequest("Movie information not match");
			}

			List<MovieCenemaScreenMappingEntity> movieCenemascreenMapppingList = movieCenemaScreenMappingRepo
					.findByMovieAndCenemaIdIn(movieOptional.get(), Arrays.asList(cenemaEntityOptional.get().getId()));
			if (movieCenemascreenMapppingList == null || movieCenemascreenMapppingList.size() <= 0) {
				return responseData.bedRequest("Movie and cenema information not match");
			}

			for (MovieCenemaScreenMappingEntity movieCenemascreenMappping : movieCenemascreenMapppingList) {
				movieCenemascreenMappping
						.setIsCurrentMovie(request.getIsCurrentMovie() ? request.getIsCurrentMovie() : false);
				movieCenemascreenMappping.setIsPastMovie(request.getIsPastMovie() ? request.getIsPastMovie() : false);
				movieCenemascreenMappping
						.setIsUpcommingMovie(request.getIsUpcommingMovie() ? request.getIsUpcommingMovie() : false);
				movieCenemascreenMappping.setTiming(request.getTiming());
			}

			movieCenemaScreenMappingRepo.saveAllAndFlush(movieCenemascreenMapppingList);

			return responseData.ok("Movie state updated with Cenema Successfully", null);

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}

	}

}
