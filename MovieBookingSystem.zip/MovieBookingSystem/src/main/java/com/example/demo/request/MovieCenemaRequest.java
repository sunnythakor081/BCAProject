package com.example.demo.request;

public class MovieCenemaRequest {
	
	
	private Integer id;
	private Integer movieId;
	private Integer cenemaId;
	private Integer cenemaScreenId;
	private String timing;
	private Boolean isCurrentMovie;
	private Boolean isUpcommingMovie;
	private Boolean isPastMovie;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getMovieId() {
		return movieId;
	}
	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}
	public Integer getCenemaId() {
		return cenemaId;
	}
	public void setCenemaId(Integer cenemaId) {
		this.cenemaId = cenemaId;
	}
	public Integer getCenemaScreenId() {
		return cenemaScreenId;
	}
	public void setCenemaScreenId(Integer cenemaScreenId) {
		this.cenemaScreenId = cenemaScreenId;
	}
	public String getTiming() {
		return timing;
	}
	public void setTiming(String timing) {
		this.timing = timing;
	}
	public Boolean getIsCurrentMovie() {
		return isCurrentMovie;
	}
	public void setIsCurrentMovie(Boolean isCurrentMovie) {
		this.isCurrentMovie = isCurrentMovie;
	}
	public Boolean getIsUpcommingMovie() {
		return isUpcommingMovie;
	}
	public void setIsUpcommingMovie(Boolean isUpcommingMovie) {
		this.isUpcommingMovie = isUpcommingMovie;
	}
	public Boolean getIsPastMovie() {
		return isPastMovie;
	}
	public void setIsPastMovie(Boolean isPastMovie) {
		this.isPastMovie = isPastMovie;
	}
	@Override
	public String toString() {
		return "MovieCenemaRequest [id=" + id + ", movieId=" + movieId + ", cenemaId=" + cenemaId + ", cenemaScreenId="
				+ cenemaScreenId + ", timing=" + timing + ", isCurrentMovie=" + isCurrentMovie + ", isUpcommingMovie="
				+ isUpcommingMovie + ", isPastMovie=" + isPastMovie + "]";
	}
	public MovieCenemaRequest(Integer id, Integer movieId, Integer cenemaId, Integer cenemaScreenId, String timing,
			Boolean isCurrentMovie, Boolean isUpcommingMovie, Boolean isPastMovie) {
		super();
		this.id = id;
		this.movieId = movieId;
		this.cenemaId = cenemaId;
		this.cenemaScreenId = cenemaScreenId;
		this.timing = timing;
		this.isCurrentMovie = isCurrentMovie;
		this.isUpcommingMovie = isUpcommingMovie;
		this.isPastMovie = isPastMovie;
	}

	
	
	
}
