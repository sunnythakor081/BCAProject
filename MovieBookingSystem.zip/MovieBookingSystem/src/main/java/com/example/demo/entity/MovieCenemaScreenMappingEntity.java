package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity(name = "movie_cenema_screen_mapping")
public class MovieCenemaScreenMappingEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@ManyToOne
	private MovieEntity movie;

	@ManyToOne
	private CenemaEntity cenema;

	@ManyToOne
	private CenemaScreenEntity cenemaScreen;

	@Column(name = "timing")
	private String timing;

	@Column(name = "is_current_movie")
	private Boolean isCurrentMovie;

	@Column(name = "is_upcomming_movie")
	private Boolean isUpcommingMovie;

	@Column(name = "is_past_movie")
	private Boolean isPastMovie;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public MovieEntity getMovie() {
		return movie;
	}

	public void setMovie(MovieEntity movie) {
		this.movie = movie;
	}

	public CenemaEntity getCenema() {
		return cenema;
	}

	public void setCenema(CenemaEntity cenema) {
		this.cenema = cenema;
	}

	public CenemaScreenEntity getCenemaScreen() {
		return cenemaScreen;
	}

	public void setCenemaScreen(CenemaScreenEntity cenemaScreen) {
		this.cenemaScreen = cenemaScreen;
	}

	public String getTiming() {
		return timing;
	}

	public void setTiming(String timing) {
		this.timing = timing;
	}

	public Boolean getIsCurrentMovie() {
		return isCurrentMovie;
	}

	public void setIsCurrentMovie(Boolean isCurrentMovie) {
		this.isCurrentMovie = isCurrentMovie;
	}

	public Boolean getIsUpcommingMovie() {
		return isUpcommingMovie;
	}

	public void setIsUpcommingMovie(Boolean isUpcommingMovie) {
		this.isUpcommingMovie = isUpcommingMovie;
	}

	public Boolean getIsPastMovie() {
		return isPastMovie;
	}

	public void setIsPastMovie(Boolean isPastMovie) {
		this.isPastMovie = isPastMovie;
	}

	@Override
	public String toString() {
		return "MovieCenemaScreenMappingEntity [id=" + id + ", movie=" + movie + ", cenema=" + cenema
				+ ", cenemaScreen=" + cenemaScreen + ", timing=" + timing + ", isCurrentMovie=" + isCurrentMovie
				+ ", isUpcommingMovie=" + isUpcommingMovie + ", isPastMovie=" + isPastMovie + "]";
	}

	public MovieCenemaScreenMappingEntity(Integer id, MovieEntity movie, CenemaEntity cenema,
			CenemaScreenEntity cenemaScreen, String timing, Boolean isCurrentMovie, Boolean isUpcommingMovie,
			Boolean isPastMovie) {
		super();
		this.id = id;
		this.movie = movie;
		this.cenema = cenema;
		this.cenemaScreen = cenemaScreen;
		this.timing = timing;
		this.isCurrentMovie = isCurrentMovie;
		this.isUpcommingMovie = isUpcommingMovie;
		this.isPastMovie = isPastMovie;
	}

	public MovieCenemaScreenMappingEntity() {
		// TODO Auto-generated constructor stub
	}

}
