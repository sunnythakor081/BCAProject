package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity (name="cenema")
public class CenemaEntity {
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "cenema_name")
	private String cenemaName;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "destrict")
	private String destrict;
	
	@Column(name = "state")
	private String state;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCenemaName() {
		return cenemaName;
	}

	public void setCenemaName(String cenemaName) {
		this.cenemaName = cenemaName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDestrict() {
		return destrict;
	}

	public void setDestrict(String destrict) {
		this.destrict = destrict;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "cenemaList [id=" + id + ", cenemaName=" + cenemaName + ", address=" + address + ", city=" + city
				+ ", destrict=" + destrict + ", state=" + state + "]";
	}

	public CenemaEntity(Integer id, String cenemaName, String address, String city, String destrict, String state) {
		super();
		this.id = id;
		this.cenemaName = cenemaName;
		this.address = address;
		this.city = city;
		this.destrict = destrict;
		this.state = state;
	}
	
	public CenemaEntity() {
		// TODO Auto-generated constructor stub
	}
	
}
