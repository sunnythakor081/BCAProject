package com.example.demo.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "ticket_booking_customer_info")
public class TicketBookingWithCustomerEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "email")
	private String email;

	@Column(name = "mobile_number")
	private String mobileNumber;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "movie_watch_date")
	private Date movieWatchDate;

	@Column(name = "timing")
	private String timing;

	@Column(name = "name")
	private String name;

	@Column(name = "total_payment")
	private String totalPayment;

	@Column(name = "is_payment_done")
	private Boolean isPaymentDone;

	@Column(name = "total_sits")
	private Integer totalSits;

	
	
	public Date getMovieWatchDate() {
		return movieWatchDate;
	}

	public void setMovieWatchDate(Date movieWatchDate) {
		this.movieWatchDate = movieWatchDate;
	}

	public String getTiming() {
		return timing;
	}

	public void setTiming(String timing) {
		this.timing = timing;
	}

	public Integer getTotalSits() {
		return totalSits;
	}

	public void setTotalSits(Integer totalSits) {
		this.totalSits = totalSits;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTotalPayment() {
		return totalPayment;
	}

	public void setTotalPayment(String totalPayment) {
		this.totalPayment = totalPayment;
	}

	public Boolean getIsPaymentDone() {
		return isPaymentDone;
	}

	public void setIsPaymentDone(Boolean isPaymentDone) {
		this.isPaymentDone = isPaymentDone;
	}

	@Override
	public String toString() {
		return "TicketBookingWithCustomerEntity [id=" + id + ", email=" + email + ", mobileNumber=" + mobileNumber
				+ ", createdDate=" + createdDate + ", name=" + name + ", totalPayment=" + totalPayment
				+ ", isPaymentDone=" + isPaymentDone + ", totalSits=" + totalSits + "]";
	}

	public TicketBookingWithCustomerEntity(Integer id, String email, String mobileNumber, Date createdDate, String name,
			String totalPayment, Boolean isPaymentDone, Integer totalSits) {
		super();
		this.id = id;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.createdDate = createdDate;
		this.name = name;
		this.totalPayment = totalPayment;
		this.isPaymentDone = isPaymentDone;
		this.totalSits = totalSits;
	}

	public TicketBookingWithCustomerEntity() {
		// TODO Auto-generated constructor stub
	}
}
