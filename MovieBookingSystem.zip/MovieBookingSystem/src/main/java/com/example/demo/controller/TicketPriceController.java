package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.request.MovieRequest;
import com.example.demo.request.TicketPriceRequest;
import com.example.demo.service.MovieService;
import com.example.demo.service.TicketPriceService;

@RestController
@RequestMapping("ticketprice")
public class TicketPriceController {
	
	@Autowired
	private TicketPriceService ticPriceService;

	@PostMapping("save")
	public ResponseEntity<Object> addPrice(@RequestBody TicketPriceRequest ticketPriceRequest) {

		return ticPriceService.addTicketPrice(ticketPriceRequest);
	}

}
