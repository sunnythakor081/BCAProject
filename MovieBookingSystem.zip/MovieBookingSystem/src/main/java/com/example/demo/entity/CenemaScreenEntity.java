package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity(name = "cenema_screen")
public class CenemaScreenEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer Id;

	@Column(name = "screen_name")
	private String screenName;

	@ManyToOne
	private CenemaEntity cenema;

	public Integer getId() {
		return Id;
	}


	public void setCenema(CenemaEntity cenema) {
		this.cenema = cenema;
	}


	public CenemaScreenEntity(Integer id, String screenName, CenemaEntity cenema) {
		super();
		Id = id;
		this.screenName = screenName;
		this.cenema = cenema;
	}

	public CenemaScreenEntity() {
		// TODO Auto-generated constructor stub
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public CenemaEntity getCenema() {
		return cenema;
	}

	public void setId(Integer id) {
		Id = id;
	}

	
}
