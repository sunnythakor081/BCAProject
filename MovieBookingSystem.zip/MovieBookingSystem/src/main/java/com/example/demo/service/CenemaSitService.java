package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entity.CenemaEntity;
import com.example.demo.entity.CenemaScreenEntity;
import com.example.demo.entity.CenemaSitEntity;
import com.example.demo.repository.CenemaRepository;
import com.example.demo.repository.CenemaScreenRepository;
import com.example.demo.repository.CenemaSitRepository;
import com.example.demo.request.CenemaSitRequest;
import com.example.demo.util.ResponseData;

@Service
public class CenemaSitService {

	@Autowired
	private CenemaSitRepository cenemaSitRepo;

	@Autowired
	private CenemaRepository cenemaRepo;

	@Autowired
	private CenemaScreenRepository cenemaScreenRepo;

	public ResponseEntity<Object> addCenemaSit(CenemaSitRequest request) {
		ResponseData responseData = new ResponseData();

		try {

			if (request == null) {
				return responseData.bedRequest("Please Provide Cenema Sit information");
			}
			if (request.getSitNumber() == null) {
				return responseData.bedRequest("Please provide Sit number");
			}
			if (request.getCenemaId() == null || request.getCenemaId() <= 0) {
				return responseData.bedRequest("Please provide cenema information");
			}
			if (request.getSection() == null || request.getSection().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please provide cenema sit section");
			}
			if (request.getCenemaScreenId() == null || request.getCenemaScreenId() <= 0) {
				return responseData.bedRequest("Please provide cenema screen information");
			}

			Optional<CenemaEntity> cenemaEntityOptional = cenemaRepo.findById(request.getCenemaId());

			if (!cenemaEntityOptional.isPresent()) {
				return responseData.bedRequest("cenema information not match");
			}

			Optional<CenemaScreenEntity> cenemaScreenEntityOptional = cenemaScreenRepo
					.findById(request.getCenemaScreenId());

			if (!cenemaScreenEntityOptional.isPresent()) {
				return responseData.bedRequest("cenema screen information not match");
			}

			if(!cenemaScreenEntityOptional.get().getCenema().equals(cenemaEntityOptional.get())) {
				return responseData.bedRequest("cenema and Cenema Screen information not match");				
			}
			
			CenemaSitEntity cenemasit = new CenemaSitEntity();

			cenemasit.setSitNumber(request.getSitNumber());
			cenemasit.setSection(request.getSection());
			cenemasit.setCenema(cenemaEntityOptional.get());
			cenemasit.setCenemaScreen(cenemaScreenEntityOptional.get());
			
			cenemaSitRepo.saveAndFlush(cenemasit);

			return responseData.ok("CenemaSit Save Successfully", cenemasit);

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}

	}

}
