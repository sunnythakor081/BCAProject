package com.example.demo.request;


public class MovieRequest {

	private Integer id;
	private String name;
	private String releaseDate;
	private String movieTimePeriod;
	private String directorName;
	private String movieType;
	private Integer movieExtensionDays;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	public String getMovieTimePeriod() {
		return movieTimePeriod;
	}
	public void setMovieTimePeriod(String movieTimePeriod) {
		this.movieTimePeriod = movieTimePeriod;
	}
	public String getDirectorName() {
		return directorName;
	}
	public void setDirectorName(String directorName) {
		directorName = directorName;
	}
	public String getMovieType() {
		return movieType;
	}
	public void setMovieType(String movieType) {
		this.movieType = movieType;
	}
	public Integer getMovieExtensionDays() {
		return movieExtensionDays;
	}
	public void setMovieExtensionDays(Integer movieExtensionDays) {
		this.movieExtensionDays = movieExtensionDays;
	}
	
	@Override
	public String toString() {
		return "MovieRequest [id=" + id + ", name=" + name + ", releaseDate=" + releaseDate + ", movieTimePeriod="
				+ movieTimePeriod + ", DirectorName=" + directorName + ", movieType=" + movieType
				+ ", movieExtensionDays=" + movieExtensionDays + "]";
	}
	public MovieRequest(Integer id, String name, String releaseDate, String movieTimePeriod, String directorName,
			String movieType, Integer movieExtensionDays) {
		super();
		this.id = id;
		this.name = name;
		this.releaseDate = releaseDate;
		this.movieTimePeriod = movieTimePeriod;
		this.directorName = directorName;
		this.movieType = movieType;
		this.movieExtensionDays = movieExtensionDays;
		
	}

	
	
}
