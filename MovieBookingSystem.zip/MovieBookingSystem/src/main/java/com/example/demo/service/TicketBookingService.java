package com.example.demo.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entity.CenemaEntity;
import com.example.demo.entity.CenemaSitEntity;
import com.example.demo.entity.MovieCenemaScreenMappingEntity;
import com.example.demo.entity.MovieEntity;
import com.example.demo.entity.TicketBookingWithCustomerEntity;
import com.example.demo.entity.TicketEntity;
import com.example.demo.entity.TicketbookingEntity;
import com.example.demo.repository.CenemaRepository;
import com.example.demo.repository.MovieCenemaScreenMappingRepository;
import com.example.demo.repository.MovieRepository;
import com.example.demo.repository.TicketBookingRepository;
import com.example.demo.repository.TicketBookingWithCustomerRepository;
import com.example.demo.repository.TicketPricerepository;
import com.example.demo.request.TicketBookingRequest;
import com.example.demo.util.ResponseData;

@Service
public class TicketBookingService {

	@Autowired
	private CenemaRepository cenemaRepo;

	@Autowired
	private MovieRepository movieRepo;

	@Autowired
	private TicketBookingRepository ticketBookingRepo;

	@Autowired
	private TicketPricerepository ticketPriceRepo;

	@Autowired
	private MovieCenemaScreenMappingRepository movieCenemaScreenMappingRepo;

	@Autowired
	private TicketBookingWithCustomerRepository ticketBookingWithCustomerRepo;

	public ResponseEntity<Object> addTicketBook(TicketBookingRequest request) {
		ResponseData responseData = new ResponseData();

		try {
			if (request == null) {
				return responseData.bedRequest("Please Provide Tckect Booking");
			}
			if (request.getCenemaId() == null || request.getCenemaId() <= 0) {
				return responseData.bedRequest("Please provide cenema name");
			}
			if (request.getCenemaSits() == null || request.getCenemaSits().size() <= 0) {
				return responseData.bedRequest("Please provide Sit number");
			}
			if (request.getMovieId() == null) {
				return responseData.bedRequest("Please provide MOvie name");
			}
			if (request.getShowTime() == null) {
				return responseData.bedRequest("Please provide Show Time");
			}
			if (request.getEmail() == null) {
				return responseData.bedRequest("Please provide email id");
			}

			if (request.getMovieWatchDate() == null) {
				return responseData.bedRequest("Please provide movie watch date");
			}

			if (request.getMobileNumber() == null) {
				return responseData.bedRequest("Please provide mobile number");
			}
			if (request.getName() == null) {
				return responseData.bedRequest("Please provide name");
			}

			Optional<CenemaEntity> cenemaEntityOptional = cenemaRepo.findById(request.getCenemaId());

			if (!cenemaEntityOptional.isPresent()) {
				return responseData.bedRequest("cenema information not match");
			}

			Optional<MovieEntity> movieOptional = movieRepo.findById(request.getMovieId());

			if (!movieOptional.isPresent()) {
				return responseData.bedRequest("Movie information not match");
			}

			MovieCenemaScreenMappingEntity movieCenemascreenMappping = movieCenemaScreenMappingRepo
					.findByMovieAndCenemaAndIsPastMovieFalse(movieOptional.get(), cenemaEntityOptional.get());
			if (movieCenemascreenMappping == null) {
				return responseData.bedRequest("Movie and cenema information not match");
			}

			Optional<TicketEntity> ticketPrice = ticketPriceRepo.findById(request.getTicketPriceId());

			if (!ticketPrice.isPresent()) {
				return responseData.bedRequest("Ticket information not match");
			}

			TicketBookingWithCustomerEntity ticketBookingWithCustomerEntity = new TicketBookingWithCustomerEntity();

			ticketBookingWithCustomerEntity.setCreatedDate(new Date());
			ticketBookingWithCustomerEntity.setEmail(request.getEmail());
			ticketBookingWithCustomerEntity.setMobileNumber(request.getMobileNumber());
			ticketBookingWithCustomerEntity
					.setIsPaymentDone(request.getIsPaymentDone() ? request.getIsPaymentDone() : false);
			ticketBookingWithCustomerEntity.setName(request.getName());
			ticketBookingWithCustomerEntity.setTotalSits(request.getCenemaSits().size());

			ticketBookingWithCustomerEntity
					.setMovieWatchDate(new SimpleDateFormat("dd-MM-yyyy").parse(request.getMovieWatchDate()));
			ticketBookingWithCustomerEntity.setTiming(request.getShowTime());
			ticketBookingWithCustomerRepo.saveAndFlush(ticketBookingWithCustomerEntity);

//			ticketBookingWithCustomerEntity.setTotalPayment(null);

			Double price = 0.0;
			List<TicketbookingEntity> ticketbookingEntityList = new ArrayList<TicketbookingEntity>();
			for (Integer sitNumber : request.getCenemaSits()) {

				TicketbookingEntity ticketBook = new TicketbookingEntity();

				ticketBook.setCenema(cenemaEntityOptional.get());
				ticketBook.setCenemaSit(new CenemaSitEntity(sitNumber));
				ticketBook.setMovie(movieOptional.get());
				ticketBook.setTicket(ticketPrice.get());
				ticketBook.setShowTime(request.getShowTime());
				ticketBook.setCenemaScreen(movieCenemascreenMappping.getCenemaScreen());
				ticketBook.setCustomerInfo(ticketBookingWithCustomerEntity);
				ticketbookingEntityList.add(ticketBook);
				price += ticketPrice.get().getTicketPrice();
			}
//			
//
			ticketBookingRepo.saveAllAndFlush(ticketbookingEntityList);
			ticketBookingWithCustomerEntity.setTotalPayment(price.toString());
			ticketBookingWithCustomerRepo.saveAndFlush(ticketBookingWithCustomerEntity);
			return responseData.ok("Ticket Booked Successfully", ticketBookingWithCustomerEntity);

		} catch (

		Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}
	}

	public ResponseEntity<Object> getTicketBasedOnticketId(Integer ticketId) {
		ResponseData responseData = new ResponseData();

		try {
			if (ticketId == null || ticketId <= 0) {
				return responseData.bedRequest("Please Provide Tckect Booking information");
			}

			Optional<TicketBookingWithCustomerEntity> ticketBookingWithCustomerEntityOptional = ticketBookingWithCustomerRepo
					.findById(ticketId);

			if (!ticketBookingWithCustomerEntityOptional.isPresent()) {
				return responseData.bedRequest("ticket information not match");
			}

			return responseData.ok("Ticket Found Successfully", ticketBookingWithCustomerEntityOptional.get());

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}
	}

}
