package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.request.CenemaRequest;
import com.example.demo.service.CenemaService;

@RestController
@RequestMapping("cenema")
public class CenemaController {

	@Autowired
	private CenemaService cenemaService;

	@PostMapping("save")
	public ResponseEntity<Object> addCenema(@RequestBody CenemaRequest cenemaReuest) {

		return cenemaService.addCenema(cenemaReuest);
	}

	@PutMapping("get_cenema_by_movie")
	public ResponseEntity<Object> getCenemaList(@RequestBody CenemaRequest request) {
		return cenemaService.findCenemaByMoviesAndArea(request);
	}
}
