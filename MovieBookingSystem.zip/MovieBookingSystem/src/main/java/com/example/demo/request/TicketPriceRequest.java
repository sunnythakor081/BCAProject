package com.example.demo.request;

public class TicketPriceRequest {

	private Integer id;
	private Integer movieId;
	private Integer cenemaId;
	private Double ticketPrice;
	private String showTimePeriod;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(Double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public String getShowTimePeriod() {
		return showTimePeriod;
	}

	public void setShowTimePeriod(String showTimePeriod) {
		this.showTimePeriod = showTimePeriod;
	}

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public Integer getCenemaId() {
		return cenemaId;
	}

	public void setCenemaId(Integer cenemaId) {
		this.cenemaId = cenemaId;
	}

	@Override
	public String toString() {
		return "TicketPriceRequest [id=" + id + ", movieId=" + movieId + ", cenemaId=" + cenemaId + ", ticketPrice="
				+ ticketPrice + ", showTimePeriod=" + showTimePeriod + "]";
	}

	public TicketPriceRequest(Integer id, Integer movieId, Integer cenemaId, Double ticketPrice,
			String showTimePeriod) {
		super();
		this.id = id;
		this.movieId = movieId;
		this.cenemaId = cenemaId;
		this.ticketPrice = ticketPrice;
		this.showTimePeriod = showTimePeriod;
	}

	public TicketPriceRequest() {
		// TODO Auto-generated constructor stub
	}

}
