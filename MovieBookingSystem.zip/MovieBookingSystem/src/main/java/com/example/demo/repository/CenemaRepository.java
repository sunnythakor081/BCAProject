package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.CenemaEntity;

import jakarta.persistence.Column;

@Repository
public interface CenemaRepository extends JpaRepository<CenemaEntity, Integer> {

	List<CenemaEntity> findByStateAndDestrictAndCity(String state, String destrict, String city);

}
