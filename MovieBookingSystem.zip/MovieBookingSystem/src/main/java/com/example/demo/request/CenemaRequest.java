package com.example.demo.request;

public class CenemaRequest {

	private Integer id;
	private String cenemaname;
	private String address;
	private String city;
	private String destrict;
	private String state;
	private Integer movieId;

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCenemaname() {
		return cenemaname;
	}

	public void setCenemaname(String cenemaname) {
		this.cenemaname = cenemaname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDestrict() {
		return destrict;
	}

	public void setDestrict(String destrict) {
		this.destrict = destrict;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public CenemaRequest(Integer id, String cenemaname, String address, String city, String destrict, String state,
			Integer movieId) {
		super();
		this.id = id;
		this.cenemaname = cenemaname;
		this.address = address;
		this.city = city;
		this.destrict = destrict;
		this.state = state;
		this.movieId = movieId;
	}

	@Override
	public String toString() {
		return "CenemaRequest [id=" + id + ", cenemaname=" + cenemaname + ", address=" + address + ", city=" + city
				+ ", destrict=" + destrict + ", state=" + state + ", movieId=" + movieId + "]";
	}

	public CenemaRequest() {
		// TODO Auto-generated constructor stub
	}

}
