package com.example.demo.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entity.MovieEntity;
import com.example.demo.repository.MovieRepository;
import com.example.demo.request.MovieRequest;
import com.example.demo.util.ResponseData;

@Service
public class MovieService {

	@Autowired
	private MovieRepository movieRepo;

	public ResponseEntity<Object> addMovie(MovieRequest request) {
		ResponseData responseData = new ResponseData();

		try {

			if (request == null) {
				return responseData.bedRequest("Please provide movie information");
			}
			if (request.getName() == null || request.getName().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please provide movie name");
			}

			if (request.getMovieType() == null || request.getMovieType().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please Provide Movie Type");
			}

			if (request.getMovieTimePeriod() == null || request.getMovieTimePeriod().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please provide Timeperiod");
			}

			if (request.getDirectorName() == null || request.getDirectorName().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please Provide DirectorName");
			}
			if (request.getMovieExtensionDays() == null || request.getMovieExtensionDays() == 0) {
				return responseData.bedRequest("Please Provide MovieExtension");
			}
			if (request.getReleaseDate() == null) {
				return responseData.bedRequest("Please Provide MovieReleaseDate");
			}

			MovieEntity movie = new MovieEntity();

			movie.setDirectorName(request.getDirectorName());
			movie.setMovieType(request.getMovieType());
			movie.setName(request.getName());
			movie.setReleaseDate(new SimpleDateFormat("dd-MM-yyyy").parse(request.getReleaseDate()));
			movie.setMovieTimePeriod(request.getMovieTimePeriod());
			movie.setMovieExtensionDays(request.getMovieExtensionDays());

			movieRepo.save(movie);

			return responseData.ok("Movie Save Successfully", movie);

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}

	}

	public ResponseEntity<Object> getAllMovie() {

		ResponseData responseData = new ResponseData();

		try {

			List<MovieEntity> movieList = movieRepo.findAll();
			if (movieList != null) {
				return responseData.ok("Here are movies we have!", movieList);
			} else {
				return responseData.bedRequest("Sorry no movie found !");
			}

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}
	}
}
