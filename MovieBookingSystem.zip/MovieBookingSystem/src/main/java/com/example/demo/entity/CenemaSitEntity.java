package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity(name = "cinema_sit")
public class CenemaSitEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@ManyToOne
	private CenemaEntity cenema;

	@ManyToOne
	private CenemaScreenEntity cenemaScreen;

	@Column(name = "section")
	private String section;

	@Column(name = "sit_number")
	private Integer sitNumber;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CenemaEntity getCenema() {
		return cenema;
	}

	public void setCenema(CenemaEntity cenema) {
		this.cenema = cenema;
	}

	public CenemaScreenEntity getCenemaScreen() {
		return cenemaScreen;
	}

	public void setCenemaScreen(CenemaScreenEntity cenemaScreen) {
		this.cenemaScreen = cenemaScreen;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public Integer getSitNumber() {
		return sitNumber;
	}

	public void setSitNumber(Integer sitNumber) {
		this.sitNumber = sitNumber;
	}

	@Override
	public String toString() {
		return "CenemaSitEntity [id=" + id + ", cenema=" + cenema + ", cenemaScreen=" + cenemaScreen + ", section="
				+ section + ", sitNumber=" + sitNumber + "]";
	}

	public CenemaSitEntity(Integer id, CenemaEntity cenema, CenemaScreenEntity cenemaScreen, String section,
			Integer sitNumber) {
		super();
		this.id = id;
		this.cenema = cenema;
		this.cenemaScreen = cenemaScreen;
		this.section = section;
		this.sitNumber = sitNumber;
	}

	public CenemaSitEntity() {
		// TODO Auto-generated constructor stub
	}

	public CenemaSitEntity(Integer id) {
		super();
		this.id = id;
	}

}
