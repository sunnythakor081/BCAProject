package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.CenemaEntity;
import com.example.demo.entity.MovieCenemaScreenMappingEntity;
import com.example.demo.entity.MovieEntity;

@Repository
public interface MovieCenemaScreenMappingRepository extends JpaRepository<MovieCenemaScreenMappingEntity, Integer> {

	List<MovieCenemaScreenMappingEntity> findByMovieAndCenemaIdIn(MovieEntity movieEntity, List<Integer> cenemaIds);

	List<MovieCenemaScreenMappingEntity> findByCenemaAndIsCurrentMovieTrue(CenemaEntity cenema);

	List<MovieCenemaScreenMappingEntity> findByCenemaAndIsPastMovieTrue(CenemaEntity cenema);

	List<MovieCenemaScreenMappingEntity> findByCenemaAndIsUpcommingMovieTrue(CenemaEntity cenema);

	MovieCenemaScreenMappingEntity findByMovieAndCenemaAndIsPastMovieFalse(MovieEntity movieEntity,
			CenemaEntity cenema);
}
