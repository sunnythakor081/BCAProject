package com.example.demo;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//			String r = "Rahul";
//			String result = "";
//			for(int i = r.length()-1;i>=0;i--) {
//				result = result + r.charAt(i);
//			}
//			
//			System.out.println("REverse :: "+result);
//			
//			
//			Integer n = 123;
//			Integer reverse = 0;
//			int digit = 0;
//			while(n>0) {
//				System.out.println("");
//				System.out.println("N :: "+n);
//				digit = n%10;
//				System.out.println("digit :: "+digit);
//				reverse = reverse *10+digit;
//				System.out.println("reverse d : "+reverse);
//				n = n/10;
//				System.out.println("N val :: "+n);
//				System.out.println("");
//			}
//			
//			System.out.println("");
//			System.out.println("REverse :: "+reverse);
		
		
		
		
		String s = "Java is java again java again";
		 
        char c = 'a';
 
        int count = s.length() - s.replace("a", "").length();
 
        System.out.println("Number of occurances of 'a' in "+s+" = "+count);
        System.out.println("Number of occurances of 'a' in "+s+" = "+s.replace("a", "").length());        
			
	}

}
