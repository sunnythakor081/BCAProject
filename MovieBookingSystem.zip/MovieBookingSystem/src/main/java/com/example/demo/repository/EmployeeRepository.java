package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.EmployeeEntity;

@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeEntity, Long>{

	
	List<EmployeeEntity> findByLocationAndRoleNumber(String location,Long roleNumber);
	
	List<EmployeeEntity> findByLocation(String location);
	
	List<EmployeeEntity> findByRoleNumber(l̥Long roleNumber);
}
