package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity(name = "ticket_booking")
public class TicketbookingEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@ManyToOne
	private MovieEntity movie;

	@ManyToOne
	private CenemaEntity cenema;

	@ManyToOne
	private CenemaScreenEntity cenemaScreen;

	@Column(name = "show_time")
	private String showTime;

	@ManyToOne
	private CenemaSitEntity cenemaSit;

	@ManyToOne
	private TicketEntity ticket;

	@ManyToOne
	private TicketBookingWithCustomerEntity customerInfo;

	
	   
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public MovieEntity getMovie() {
		return movie;
	}

	public void setMovie(MovieEntity movie) {
		this.movie = movie;
	}

	public CenemaEntity getCenema() {
		return cenema;
	}

	public void setCenema(CenemaEntity cenema) {
		this.cenema = cenema;
	}

	public CenemaSitEntity getCenemaSit() {
		return cenemaSit;
	}

	public void setCenemaSit(CenemaSitEntity cenemaSit) {
		this.cenemaSit = cenemaSit;
	}

	public String getShowTime() {
		return showTime;
	}

	public void setShowTime(String showTime) {
		this.showTime = showTime;
	}

	public TicketEntity getTicket() {
		return ticket;
	}

	public void setTicket(TicketEntity ticket) {
		this.ticket = ticket;
	}

	public CenemaScreenEntity getCenemaScreen() {
		return cenemaScreen;
	}

	public void setCenemaScreen(CenemaScreenEntity cenemaScreen) {
		this.cenemaScreen = cenemaScreen;
	}

	public TicketBookingWithCustomerEntity getCustomerInfo() {
		return customerInfo;
	}

	public void setCustomerInfo(TicketBookingWithCustomerEntity customerInfo) {
		this.customerInfo = customerInfo;
	}

	@Override
	public String toString() {
		return "TicketbookingEntity [id=" + id + ", movie=" + movie + ", cenema=" + cenema + ", cenemaScreen="
				+ cenemaScreen + ", showTime=" + showTime + ", cenemaSit=" + cenemaSit + ", ticket=" + ticket
				+ ", customerInfo=" + customerInfo + "]";
	}

	public TicketbookingEntity(Integer id, MovieEntity movie, CenemaEntity cenema, CenemaScreenEntity cenemaScreen,
			String showTime, CenemaSitEntity cenemaSit, TicketEntity ticket,
			TicketBookingWithCustomerEntity customerInfo) {
		super();
		this.id = id;
		this.movie = movie;
		this.cenema = cenema;
		this.cenemaScreen = cenemaScreen;
		this.showTime = showTime;
		this.cenemaSit = cenemaSit;
		this.ticket = ticket;
		this.customerInfo = customerInfo;
	}

	public TicketbookingEntity() {
		// TODO Auto-generated constructor stub
	}
}
