package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.EmployeeEntity;
import com.example.demo.repository.EmployeeRepository;

@RestController
@RequestMapping("employeeinfo")
public class EmployeeController {

	@Autowired
	EmployeeRepository emprepo;
	
	@GetMapping("fhdfd/{location}")
	private ResponseEntity<Object> getEmployeeInfo(@RequestParam("location") String location,@RequestParam("roleNumber") Long rolenumber){
	
		
		try {
			
			List<EmployeeEntity> empList = null;
			
			if(location !=null && rolenumber !=null) {
				
				empList = emprepo.findByLocationAndRoleNumber(location, rolenumber);
				
			} else if(location !=null && rolenumber ==null) {
				empList = emprepo.findByLocation(location);				
			} else if(location ==null && rolenumber !=null) {
				
				empList = emprepo.findByRoleNumber(rolenumber);
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return null;
	}
}
