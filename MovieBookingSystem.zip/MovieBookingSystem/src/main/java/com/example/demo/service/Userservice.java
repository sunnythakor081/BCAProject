package com.example.demo.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entity.UserEntity;
import com.example.demo.repository.UserRepository;
import com.example.demo.request.userRequest;
import com.example.demo.util.ResponseData;

@Service
public class Userservice {
	
private UserRepository userRepo;
	
	public ResponseEntity<Object> addUser(userRequest request){
		ResponseData responseData= new ResponseData();
	
		try {
			if(request==null) {
				return responseData.bedRequest("Please Provide User");
			}
			if (request.getId()== null) {
				return responseData.bedRequest("Please provide User Id");
			}
			if (request.getName() == null || request.getName().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please provide User Name");
			}
			if (request.getPassword() == null) {
				return responseData.bedRequest("Please provide User Password");
			}
			if (request.getMobileNumber() == null) {
				return responseData.bedRequest("Please provide Mobile Number");
			}
			if (request.getEmail() == null) {
				return responseData.bedRequest("Please provide Email");
			}
			if (request.getCreatedDate() == null) {
				return responseData.bedRequest("Please provide Date");
			}
			
			UserEntity user = new UserEntity();

			user.setCreatedDate(request.getCreatedDate());
			user.setEmail(request.getEmail());
			user.setId(request.getId());
			user.setMobileNumber(request.getMobileNumber());
			user.setName(request.getName());
			user.setPassword(request.getPassword());
			
			userRepo.save(user);

			return responseData.ok("User Save Successfully",user);
			
		}
		catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}
	}
	

}
