package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.request.CenemaSitRequest;
import com.example.demo.service.CenemaSitService;

@RestController
@RequestMapping("cenemasit")
public class CenemaSitController {
	
	

	@Autowired
	private CenemaSitService senemSitService;

	@PostMapping("save")
	public ResponseEntity<Object> addCenemaSit(@RequestBody CenemaSitRequest cenemaSitRequest) {

		return senemSitService.addCenemaSit(cenemaSitRequest);
	}
	

}
