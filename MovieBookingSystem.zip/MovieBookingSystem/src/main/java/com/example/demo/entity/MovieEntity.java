package com.example.demo.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name="movie")
public class MovieEntity {

	@Id
	 @GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name="name")
	private String name;

	@Column(name="release_date")
	private Date releaseDate;
	
	@Column(name="movie_time_period")
	private String movieTimePeriod;
	
	@Column(name="director_name")
	private String DirectorName;
	
	@Column(name="movie_type")
	private String movieType;
	
	@Column(name="movie_extension_days")
	private Integer movieExtensionDays;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getMovieTimePeriod() {
		return movieTimePeriod;
	}

	public void setMovieTimePeriod(String movieTimePeriod) {
		this.movieTimePeriod = movieTimePeriod;
	}

	public String getDirectorName() {
		return DirectorName;
	}

	public void setDirectorName(String directorName) {
		DirectorName = directorName;
	}

	public String getMovieType() {
		return movieType;
	}

	public void setMovieType(String movieType) {
		this.movieType = movieType;
	}

	public Integer getMovieExtensionDays() {
		return movieExtensionDays;
	}

	public void setMovieExtensionDays(Integer movieExtensionDays) {
		this.movieExtensionDays = movieExtensionDays;
	}
	
	
	
	
	
	public MovieEntity() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "MovieEntity [id=" + id + ", name=" + name + ", releaseDate=" + releaseDate + ", movieTimePeriod="
				+ movieTimePeriod + ", DirectorName=" + DirectorName + ", movieType=" + movieType
				+ ", movieExtensionDays=" + movieExtensionDays + "]";
	}

	public MovieEntity(Integer id, String name, Date releaseDate, String movieTimePeriod, String directorName,
			String movieType, Integer movieExtensionDays) {
		super();
		this.id = id;
		this.name = name;
		this.releaseDate = releaseDate;
		this.movieTimePeriod = movieTimePeriod;
		this.DirectorName = directorName;
		this.movieType = movieType;
		this.movieExtensionDays = movieExtensionDays;
	}
	
	
}
