package com.example.demo.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity(name = "movie_cenema")
public class MovieCenemaEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@ManyToOne
	private MovieEntity movie;
	
	@ManyToOne
	private CenemaEntity cenema;
	
	@Column(name = "movie_timing")
	private String movieTiming;
	
	@Column(name = "created_date")
	private Date createdDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public MovieEntity getMovie() {
		return movie;
	}

	public void setMovie(MovieEntity movie) {
		this.movie = movie;
	}

	public CenemaEntity getCenema() {
		return cenema;
	}

	public void setCenema(CenemaEntity cenema) {
		this.cenema = cenema;
	}

	public String getMovieTiming() {
		return movieTiming;
	}

	public void setMovieTiming(String movieTiming) {
		this.movieTiming = movieTiming;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public MovieCenemaEntity(Integer id, MovieEntity movie, CenemaEntity cenema, String movieTiming, Date createdDate) {
		super();
		this.id = id;
		this.movie = movie;
		this.cenema = cenema;
		this.movieTiming = movieTiming;
		this.createdDate = createdDate;
	}


	

}
