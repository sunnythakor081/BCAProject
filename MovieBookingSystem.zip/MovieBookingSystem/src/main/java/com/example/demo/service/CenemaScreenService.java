package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entity.CenemaEntity;
import com.example.demo.entity.CenemaScreenEntity;
import com.example.demo.repository.CenemaRepository;
import com.example.demo.repository.CenemaScreenRepository;
import com.example.demo.request.CenemaScreenRequest;
import com.example.demo.util.ResponseData;

@Service
public class CenemaScreenService {

	@Autowired
	private CenemaScreenRepository cenemaScreenRepo;

	@Autowired
	private CenemaRepository cenemaRepo;

	public ResponseEntity<Object> addSreen(CenemaScreenRequest request) {
		ResponseData responseData = new ResponseData();

		try {

			if (request == null) {
				return responseData.bedRequest("Please provide Cenema Screen information");
			}

			if (request.getCenemaScreenName() == null || request.getCenemaScreenName().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please provide Screen name");
			}

			if (request.getCenemaId() == null || request.getCenemaId() <= 0) {
				return responseData.bedRequest("Please provide cenema");
			}

			Optional<CenemaEntity> cenemaEntityOptional = cenemaRepo.findById(request.getCenemaId());

			if (!cenemaEntityOptional.isPresent()) {
				return responseData.bedRequest("Cenema not found based on your Information!!");
			}

			CenemaScreenEntity cenemaScreen = new CenemaScreenEntity();

			cenemaScreen.setCenema(cenemaEntityOptional.get());
			cenemaScreen.setScreenName(request.getCenemaScreenName());

			cenemaScreenRepo.saveAndFlush(cenemaScreen);

			return responseData.ok("Cenema Screen Save Successfully", cenemaScreen);

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}
	}
}
