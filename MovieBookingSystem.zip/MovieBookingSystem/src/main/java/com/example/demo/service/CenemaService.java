package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entity.CenemaEntity;
import com.example.demo.entity.MovieCenemaScreenMappingEntity;
import com.example.demo.entity.MovieEntity;
import com.example.demo.repository.CenemaRepository;
import com.example.demo.repository.MovieCenemaScreenMappingRepository;
import com.example.demo.repository.MovieRepository;
import com.example.demo.request.CenemaRequest;
import com.example.demo.util.ResponseData;

@Service
public class CenemaService {

	@Autowired
	private CenemaRepository cenemarepo;

	@Autowired
	private MovieRepository movierepo;

	@Autowired
	private MovieCenemaScreenMappingRepository movieCenemaScreenRepo;

	public ResponseEntity<Object> findCenemaByMoviesAndArea(CenemaRequest request) {
		ResponseData responseData = new ResponseData();

		try {
			if (request == null) {
				return responseData.bedRequest("Please Provide Cenema information");
			}
			if (request.getCity() == null || request.getCity().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please Provide City");
			}
			if (request.getDestrict() == null || request.getDestrict().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please Provide Destrict");
			}
			if (request.getState() == null || request.getState().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please Provide State");
			}
			if (request.getMovieId() == null || request.getMovieId() <= 0) {
				return responseData.bedRequest("Please Provide Movie information");
			}

			Optional<MovieEntity> movieEntityOptional = movierepo.findById(request.getMovieId());

			if (!movieEntityOptional.isPresent()) {
				return responseData.bedRequest("movie information not found");
			}

			List<CenemaEntity> cenemaList = cenemarepo.findByStateAndDestrictAndCity(request.getState(),
					request.getDestrict(), request.getCity());

			if (cenemaList == null) {
				return responseData.bedRequest("No cenema found!");
			}

			List<MovieCenemaScreenMappingEntity> movieCenemaScreenMappingList = movieCenemaScreenRepo
					.findByMovieAndCenemaIdIn(movieEntityOptional.get(),
							cenemaList.stream().map(s -> s.getId()).collect(Collectors.toList()));

			if (movieCenemaScreenMappingList == null || movieCenemaScreenMappingList.isEmpty()) {
				return responseData.bedRequest("No cenema found!");
			}

			cenemaList = movieCenemaScreenMappingList.stream().map(s -> s.getCenema()).collect(Collectors.toList());

			return responseData.ok("Cenema Found Successfully", cenemaList);

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}
	}

	public ResponseEntity<Object> addCenema(CenemaRequest request) {
		ResponseData responseData = new ResponseData();

		try {
			if (request == null) {
				return responseData.bedRequest("Please Provide request information");
			}
			if (request.getCenemaname() == null || request.getCenemaname().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please provide Cenema Name");
			}
			if (request.getAddress() == null || request.getAddress().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please provide Address");
			}
			if (request.getCity() == null || request.getCity().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please Provide City");
			}
			if (request.getDestrict() == null || request.getDestrict().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please Provide Destrict");
			}
			if (request.getState() == null || request.getState().trim().equalsIgnoreCase("")) {
				return responseData.bedRequest("Please Provide State");
			}

			CenemaEntity cenema = new CenemaEntity();

			cenema.setAddress(request.getAddress());
			cenema.setCenemaName(request.getCenemaname());
			cenema.setCity(request.getCity());
			cenema.setState(request.getState());
			cenema.setDestrict(request.getDestrict());

			cenemarepo.save(cenema);

			return responseData.ok("Cenema Save Successfully", cenema);

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}

	}

}
