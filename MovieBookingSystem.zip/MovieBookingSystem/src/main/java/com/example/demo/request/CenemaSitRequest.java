package com.example.demo.request;

import com.example.demo.entity.CenemaEntity;
import com.example.demo.entity.CenemaScreenEntity;

import jakarta.persistence.Column;
import jakarta.persistence.ManyToOne;

public class CenemaSitRequest {
	
	private Integer id;
	private String section;
	private Integer sitNumber;
	private Integer cenemaId;
	private Integer cenemaScreenId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public Integer getSitNumber() {
		return sitNumber;
	}
	public void setSitNumber(Integer sitNumber) {
		this.sitNumber = sitNumber;
	}
	public Integer getCenemaId() {
		return cenemaId;
	}
	public void setCenemaId(Integer cenemaId) {
		this.cenemaId = cenemaId;
	}
	public Integer getCenemaScreenId() {
		return cenemaScreenId;
	}
	public void setCenemaScreenId(Integer cenemaScreenId) {
		this.cenemaScreenId = cenemaScreenId;
	}
	@Override
	public String toString() {
		return "CenemaSitRequest [id=" + id + ", section=" + section + ", sitNumber=" + sitNumber + ", cenemaId="
				+ cenemaId + ", cenemaScreenId=" + cenemaScreenId + "]";
	}
	public CenemaSitRequest(Integer id, String section, Integer sitNumber, Integer cenemaId, Integer cenemaScreenId) {
		super();
		this.id = id;
		this.section = section;
		this.sitNumber = sitNumber;
		this.cenemaId = cenemaId;
		this.cenemaScreenId = cenemaScreenId;
	}
	

	

}
