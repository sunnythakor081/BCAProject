package com.example.demo.request;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;

public class TicketBookingRequest {

	private Integer id;
	private Integer movieId;
	private Integer cenemaId;
	private String showTime;
	private List<Integer> cenemaSits;
	private Integer ticketPriceId;
	private String email;
	private String mobileNumber;
	private String name;
	private Double totalPayment;
	private Boolean isPaymentDone;
	private String movieWatchDate;

	public String getMovieWatchDate() {
		return movieWatchDate;
	}

	public void setMovieWatchDate(String movieWatchDate) {
		this.movieWatchDate = movieWatchDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public Integer getCenemaId() {
		return cenemaId;
	}

	public void setCenemaId(Integer cenemaId) {
		this.cenemaId = cenemaId;
	}

	public String getShowTime() {
		return showTime;
	}

	public void setShowTime(String showTime) {
		this.showTime = showTime;
	}

	public List<Integer> getCenemaSits() {
		return cenemaSits;
	}

	public void setCenemaSits(List<Integer> cenemaSits) {
		this.cenemaSits = cenemaSits;
	}

	public Integer getTicketPriceId() {
		return ticketPriceId;
	}

	public void setTicketPriceId(Integer ticketPriceId) {
		this.ticketPriceId = ticketPriceId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getTotalPayment() {
		return totalPayment;
	}

	public void setTotalPayment(Double totalPayment) {
		this.totalPayment = totalPayment;
	}

	public Boolean getIsPaymentDone() {
		return isPaymentDone;
	}

	public void setIsPaymentDone(Boolean isPaymentDone) {
		this.isPaymentDone = isPaymentDone;
	}

	@Override
	public String toString() {
		return "TicketBookingRequest [id=" + id + ", movieId=" + movieId + ", cenemaId=" + cenemaId + ", showTime="
				+ showTime + ", cenemaSits=" + cenemaSits + ", ticketPriceId=" + ticketPriceId + ", email=" + email
				+ ", mobileNumber=" + mobileNumber + ", name=" + name + ", totalPayment=" + totalPayment
				+ ", isPaymentDone=" + isPaymentDone + ", movieWatchDate=" + movieWatchDate + "]";
	}

	public TicketBookingRequest(Integer id, Integer movieId, Integer cenemaId, String showTime,
			List<Integer> cenemaSits, Integer ticketPriceId, String email, String mobileNumber, String name,
			Double totalPayment, Boolean isPaymentDone, String movieWatchDate) {
		super();
		this.id = id;
		this.movieId = movieId;
		this.cenemaId = cenemaId;
		this.showTime = showTime;
		this.cenemaSits = cenemaSits;
		this.ticketPriceId = ticketPriceId;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.name = name;
		this.totalPayment = totalPayment;
		this.isPaymentDone = isPaymentDone;
		this.movieWatchDate = movieWatchDate;
	}

	public TicketBookingRequest() {
		// TODO Auto-generated constructor stub
	}
}
