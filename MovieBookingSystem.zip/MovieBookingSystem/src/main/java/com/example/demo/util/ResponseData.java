package com.example.demo.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ResponseData {

	public ResponseEntity<Object> ok(String message, Object data) {
		return new ResponseEntity<>(new Response(true, message, data), HttpStatus.OK);
	}

	public ResponseEntity<Object> somethingWentWrong() {
		return new ResponseEntity<>(new Response(false, "Something Went Wrong, Please try again !!", null), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	public ResponseEntity<Object> bedRequest(String message) {
		return new ResponseEntity<>(new Response(false, message, null), HttpStatus.BAD_REQUEST );
	}
	
}

class Response {
	private Boolean status;
	private String message;
	private Object data;

	public Response(Boolean status, String message, Object data) {
		super();
		this.status = status;
		this.message = message;
		this.data = data;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	
}