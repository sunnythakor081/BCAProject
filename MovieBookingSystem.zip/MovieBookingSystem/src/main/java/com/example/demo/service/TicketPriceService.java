package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entity.CenemaEntity;
import com.example.demo.entity.MovieEntity;
import com.example.demo.entity.TicketEntity;
import com.example.demo.repository.CenemaRepository;
import com.example.demo.repository.MovieRepository;
import com.example.demo.repository.TicketPricerepository;
import com.example.demo.request.TicketPriceRequest;
import com.example.demo.util.ResponseData;

@Service
public class TicketPriceService {

	@Autowired
	private TicketPricerepository ticketPricerepo;

	@Autowired
	private CenemaRepository cenemaRepo;

	@Autowired
	private MovieRepository movieRepo;

	public ResponseEntity<Object> addTicketPrice(TicketPriceRequest request) {
		ResponseData responseData = new ResponseData();

		try {
			if (request == null) {
				return responseData.bedRequest("Please Provide TckectPrice");
			}
			if (request.getCenemaId() == null || request.getCenemaId() <= 0) {
				return responseData.bedRequest("Please provide cenema name");
			}
			if (request.getMovieId() == null || request.getCenemaId() <= 0) {
				return responseData.bedRequest("Please provide MOvie name");
			}
//			if (request.getShowTimePeriod() == null) {
//				return responseData.bedRequest("Please provide Show Time");
//			}
			if (request.getTicketPrice() == null) {
				return responseData.bedRequest("Please provide TicketPrice");
			}

			Optional<CenemaEntity> cenemaEntityOptional = cenemaRepo.findById(request.getCenemaId());

			if (!cenemaEntityOptional.isPresent()) {
				return responseData.bedRequest("cenema information not match");
			}

			Optional<MovieEntity> movieOptional = movieRepo.findById(request.getMovieId());

			if (!movieOptional.isPresent()) {
				return responseData.bedRequest("Movie information not match");
			}

			TicketEntity ticketPrice = new TicketEntity();

			ticketPrice.setCenema(cenemaEntityOptional.get());
			ticketPrice.setId(request.getId());
			ticketPrice.setMovie(movieOptional.get());
//			ticketPrice.setShowTimePeriod(request.getShowTimePeriod());
			ticketPrice.setTicketPrice(request.getTicketPrice());

			ticketPricerepo.saveAndFlush(ticketPrice);

			return responseData.ok("TicketPrice Save Successfully", ticketPrice);

		} catch (Exception e) {
			e.printStackTrace();
			return responseData.somethingWentWrong();
		}
	}

}
